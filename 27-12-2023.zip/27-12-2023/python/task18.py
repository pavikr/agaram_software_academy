cost_price=float(input("enter your product actual cost price:"))
selling_price=float(input("enter your product selling cost price:"))
if(selling_price>cost_price):
    print("profit")
else:
    print("loss")