unit=int(input("Enter total unit consumed:"))
if(unit<=50):
    amount=unit*0.50
elif(unit<=150):
    amount=unit*0.50+(unit-50)*0.75
elif(unit<=250):
    amount=unit*0.50+(unit-50)*0.75+(unit-150)*1.20
else:
    amount=unit*0.50+(unit-50)*0.75+(unit-250)*1.50
    surcharge=amount*0.20
    total=amount+surcharge
    print("Total electricity bill of Rs:",total)
    


