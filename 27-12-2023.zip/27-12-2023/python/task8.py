chr=input("Enter any alphabet:")
if(chr=='a'or chr=='A'or chr=='e' or chr=='E'or chr=='i' or chr=='I' or chr=='o' or chr=='O' or chr=='u' or chr=='U'):
    print(chr, "is a vowel")
else:
    print(chr, "is a consonant")