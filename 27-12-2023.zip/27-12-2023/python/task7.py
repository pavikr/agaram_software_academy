ch=input("enter any variable:")
if ((ch>='a' and ch<='z') or (ch>='A' and ch<='Z')):
    print(ch ,"is an alphabet")
else:
    print(ch ,"is not alphabet")
