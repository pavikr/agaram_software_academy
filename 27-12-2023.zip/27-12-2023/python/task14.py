a=int(input("Enter the first value:"))
b=int(input("Enter the second value:"))
c=int(input("Enter the first value:"))
total=a+b+c
if total==180:
    print("The given triangle is valid")
else:
    print("The given triange is invalid")
