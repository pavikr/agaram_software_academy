a=int(input("enter your number:"))
if (a%5==0 and a%11==0):
    print("a is divisible by 5 and 11")
else:
    print("a is not divisible 5 and 11")