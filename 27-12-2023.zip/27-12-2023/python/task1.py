a=int(input("Enter your first number:"))
b=int(input("Enter your second number:"))
if a>b:
    print("a is greater than b")
else:
    print("b is greater than a")
