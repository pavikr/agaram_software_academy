a=int(input("Enter your number: "))
if a>0:
    print("a is poitive number")
elif a==0:
    print("a i equal to 0")
else:
    print("a is nagative number")
