a=int(input("Enter your first number: "))
b=int(input("Enter your second number: "))
c=int(input("Enter your third number: "))
if a>b and a>c:
    print("a is greater")
elif b>c and b>a:
    print("b is greater")
else:
    print("c is greater")
