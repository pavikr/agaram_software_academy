a=int(input("enter your number:"))
if a%2==0:
    print("a is even number")
else:
    print("a is odd number")