week_number=int(input("enter week number:"))
if week_number==1:
    print("The day is sunday")
elif week_number==2:
    print("The day is Monday")
elif week_number==3:
    print("The day is Tuesday")
elif week_number==4:
    print("The day is Wednesday")
elif week_number==5:
    print("The day is Thursday")
elif week_number==6:
    print("The day is Friday")
elif week_number==7:
    print("The day is Saturday")
else:
    print("Invalid number")