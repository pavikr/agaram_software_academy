chr=input("enter any alphabet:")
if(chr>="a" and chr<="z"):
    print(chr,"The given alphabet is lowercase")
else:
    print(chr,"The given alphabet is uppercase")
